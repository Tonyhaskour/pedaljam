<div id="{{uc_id}}" class="ue-nav-menu" data-show-icons="{{show_expand_collapse_icons}}" data-breakpoint="{{responsive_breakpoint}}" data-full-width="{{full_width_on_mobile}}" data-effect-style="{{styles}}">
  
  <div class="ue-nav-menu-mobile-wrapper">
    <label class="ue-nav-menu-mobile" for="mobile_menu{{uc_id}}">
      <span class="ue-nav-menu-mobile-icon-open">{{mobile_icon_html|raw}}</span>
      <span class="ue-nav-menu-mobile-icon-close">{{mobile_icon_close_html|raw}}</span>
    </label>
  </div>  
  
  <input id="mobile_menu{{uc_id}}" class="ue-nav-menu-checkbox" type="checkbox">
  
  {{menu|raw}}
  
  <div class="ue-nav-menu-icons-holder" style="display: none;">
    <span class="ue-nav-menu-icon-expand">{{expand_icon_html|raw}}</span>
    <span class="ue-nav-menu-icon-collapse">{{collapse_icon_html|raw}}</span>
    <span class="ue-nav-menu-icon-first-level-expand">{{first_level_expand_icon_html|raw}}</span>
  </div>
  
</div>